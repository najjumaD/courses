Here you find some old (mock) exams of mine.

The password is available on request.

I have no more publishable solutions. 

If you find any errors or inaccuracies, please do not hesitate to let me know.

## By the file name you can see to which course the exam belongs:

| Acronym | Course |
| ----------- | ----------- |
| ie | 	International Economics| 
| cla | 	Calculus| 
| instat |	Inferential Statistics| 
| destat |	Descriptive Statistics| 
| macro |	Macroeconomics| 
| micro |	Microeconomics| 
| R	| The Programming Language R| 
| mrada |	The Programming Language R| 
| jdm	| Judgement and Decision Making| 
| oib	| Organization of International Businesses| 	
